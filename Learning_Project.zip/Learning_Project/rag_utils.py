"""
rag_utils.py — RAG pipeline utilities
======================================
Houses every step of the Retrieval-Augmented Generation pipeline:
  load → split → embed → store (with metadata) → retrieve → generate → cite sources

All functions are pure helpers consumed by the Streamlit app (app.py).
"""

import os
import shutil
import tempfile
import logging
from typing import List, Tuple, Optional

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_groq import ChatGroq
from langchain_core.documents import Document

# Setup basic logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

PERSIST_DIR = "./chroma_db"

# ---------------------------------------------------------------------------
# 1. LOAD — Read pages from a single PDF file with OCR/Text check
# ---------------------------------------------------------------------------

def load_pdf(uploaded_file) -> List[Document]:
    """
    Accept a Streamlit UploadedFile, write it to a temp file so PyPDFLoader
    can read it, and return a list of LangChain Document objects (one per page).

    Checks if total extracted text is empty or minimal (e.g. scanned image PDF).
    """
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(uploaded_file.getbuffer())
        tmp_path = tmp.name

    try:
        loader = PyPDFLoader(tmp_path)
        pages = loader.load()  # List[Document]
    except Exception as e:
        logger.error(f"Failed to parse PDF '{uploaded_file.name}': {e}")
        raise ValueError(f"Could not read PDF '{uploaded_file.name}'. File may be corrupt or invalid.")
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)

    if not pages:
        raise ValueError(f"'{uploaded_file.name}' appears to be empty — no pages found.")

    # Validate if text was actually extracted (check for scanned/image-only PDFs)
    total_text_length = sum(len(page.page_content.strip()) for page in pages)
    if total_text_length < 30:
        raise ValueError(
            f"'{uploaded_file.name}' appears to be a scanned or image-only PDF with no extractable text. "
            "OCR preprocessing is required for image-based PDFs."
        )

    logger.info(f"Successfully loaded '{uploaded_file.name}' ({len(pages)} pages, {total_text_length} characters).")
    return pages


# ---------------------------------------------------------------------------
# 2. SPLIT — Break pages into table-aware, overlapping chunks
# ---------------------------------------------------------------------------

def split_documents(
    pages: List[Document],
    chunk_size: int = 1500,
    chunk_overlap: int = 300,
) -> List[Document]:
    """
    Use RecursiveCharacterTextSplitter to break long pages into manageable chunks.
    chunk_size=1500 & chunk_overlap=300 are optimized to keep financial tables,
    ratios, and multi-row sections intact within a single context block.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""],  # Try clean breaks first
    )
    chunks = splitter.split_documents(pages)
    logger.info(f"Split {len(pages)} pages into {len(chunks)} chunks (size={chunk_size}, overlap={chunk_overlap}).")
    return chunks


# ---------------------------------------------------------------------------
# 3. TAG — Enrich every chunk's metadata with source filename & page number
# ---------------------------------------------------------------------------

def tag_chunks_with_source(chunks: List[Document], filename: str) -> List[Document]:
    """
    Stamp each chunk with {"source": filename} and ensure human-readable 
    page numbers are preserved.
    """
    for chunk in chunks:
        chunk.metadata["source"] = filename
        # PyPDFLoader usually stores 0-indexed page in chunk.metadata['page']
        raw_page = chunk.metadata.get("page", 0)
        chunk.metadata["page_number"] = raw_page + 1  # 1-indexed page
    return chunks


# ---------------------------------------------------------------------------
# 4. EMBED + STORE — Generate embeddings and persist into ChromaDB
# ---------------------------------------------------------------------------

def get_embedding_model() -> HuggingFaceEmbeddings:
    """
    Return a HuggingFace sentence-transformer embedding model.
    Uses 'all-MiniLM-L6-v2' — lightweight, fast, and free.
    """
    return HuggingFaceEmbeddings(
        model_name="all-MiniLM-L6-v2",
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def load_existing_vectorstore(embedding_model: HuggingFaceEmbeddings) -> Optional[Chroma]:
    """
    Check if a persisted ChromaDB database exists on disk.
    If yes, load and return it so the knowledge base survives app restarts.
    """
    if os.path.exists(PERSIST_DIR) and len(os.listdir(PERSIST_DIR)) > 0:
        logger.info(f"Loading existing ChromaDB from disk at {PERSIST_DIR}")
        return Chroma(
            persist_directory=PERSIST_DIR,
            embedding_function=embedding_model,
            collection_name="rag_chatbot",
        )
    return None


def reset_vectorstore(vectorstore: Optional[Chroma] = None) -> bool:
    """
    Properly close the ChromaDB connection and delete the persisted database.
    On Windows, files cannot be deleted while they are locked by an active process,
    so we must release the connection FIRST, then delete the folder.

    Returns True if reset was successful, False otherwise.
    """
    import gc
    import time

    # Step 1: Delete the collection inside ChromaDB (releases internal locks)
    if vectorstore is not None:
        try:
            vectorstore.delete_collection()
            logger.info("ChromaDB collection deleted.")
        except Exception as e:
            logger.warning(f"Could not delete collection: {e}")

        # Step 2: Reset the underlying ChromaDB client
        try:
            if hasattr(vectorstore, '_client'):
                vectorstore._client.clear_system_cache()
        except Exception as e:
            logger.warning(f"Could not clear client cache: {e}")

    # Step 3: Remove all Python references so Windows releases file locks
    vectorstore = None
    gc.collect()
    time.sleep(0.5)  # Brief pause to let Windows release file handles

    # Step 4: Delete the folder from disk
    if os.path.exists(PERSIST_DIR):
        try:
            shutil.rmtree(PERSIST_DIR)
            logger.info(f"Successfully deleted '{PERSIST_DIR}' from disk.")
            return True
        except PermissionError:
            logger.warning(f"Windows still locking files. Retrying after delay...")
            time.sleep(1)
            try:
                shutil.rmtree(PERSIST_DIR)
                logger.info(f"Successfully deleted '{PERSIST_DIR}' on retry.")
                return True
            except Exception as e:
                logger.error(f"Failed to delete '{PERSIST_DIR}': {e}")
                return False
        except Exception as e:
            logger.error(f"Failed to delete '{PERSIST_DIR}': {e}")
            return False

    return True


def create_or_update_vectorstore(
    chunks: List[Document],
    embedding_model: HuggingFaceEmbeddings,
    existing_vectorstore: Optional[Chroma] = None,
) -> Chroma:
    """
    Upsert documents into ChromaDB with disk persistence enabled.
    """
    if existing_vectorstore is None:
        vectorstore = Chroma.from_documents(
            documents=chunks,
            embedding=embedding_model,
            collection_name="rag_chatbot",
            persist_directory=PERSIST_DIR,
        )
    else:
        existing_vectorstore.add_documents(documents=chunks)
        vectorstore = existing_vectorstore

    logger.info(f"Vector store updated and persisted to '{PERSIST_DIR}'.")
    return vectorstore


# ---------------------------------------------------------------------------
# 5. RETRIEVE — Find top-k relevant chunks for a user question
# ---------------------------------------------------------------------------

def retrieve_relevant_chunks(
    vectorstore: Chroma,
    query: str,
    top_k: int = 8,
) -> List[Document]:
    """
    Embed the user's question and perform a similarity search against ChromaDB.
    Defaults to top_k=8 to ensure comprehensive multi-document coverage (e.g. QoQ).
    """
    results = vectorstore.similarity_search(query, k=top_k)
    logger.info(f"Retrieved {len(results)} chunks for query: '{query}'")
    return results


# ---------------------------------------------------------------------------
# 6. GENERATE — Send context + question to the LLM
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = (
    "You are a helpful assistant. Answer the user's question using ONLY the "
    "following context, which may come from multiple documents.\n"
    "If the answer is not in the context, say: "
    "'I don't know based on the uploaded documents.'\n\n"
    "Context:\n{context}\n\n"
    "Question: {question}"
)


def build_context_string(chunks: List[Document]) -> str:
    """
    Concatenate chunk texts into a single context string for the LLM prompt.
    """
    return "\n\n---\n\n".join(chunk.page_content for chunk in chunks)


def get_llm(api_key: str, model: str = "openai/gpt-oss-120b") -> ChatGroq:
    """
    Instantiate the Groq chat model.
    Default model: openai/gpt-oss-120b (Recommended replacement for Llama 3.3 70B).
    """
    return ChatGroq(
        model_name=model,
        temperature=0.2,
        groq_api_key=api_key,
    )


def generate_answer(
    llm: ChatGroq,
    question: str,
    chunks: List[Document],
) -> Tuple[str, List[str]]:
    """
    Full RAG generation step:
      1. Build context string.
      2. Format strict prompt.
      3. Call LLM.
      4. Extract unique source citations with page numbers.
    """
    context = build_context_string(chunks)
    prompt = SYSTEM_PROMPT.format(context=context, question=question)

    response = llm.invoke(prompt)
    answer = response.content

    # Extract source citations with page numbers (e.g. "Bajaj_Q1.pdf (Page 4)")
    sources_set = set()
    for chunk in chunks:
        src = chunk.metadata.get("source", "Unknown")
        page = chunk.metadata.get("page_number") or (chunk.metadata.get("page", 0) + 1)
        sources_set.add(f"{src} (Page {page})")

    sources = sorted(list(sources_set))
    return answer, sources
