# 📄 Financial & Document RAG Chatbot

An advanced **Retrieval-Augmented Generation** (RAG) chatbot built with **Streamlit** and **LangChain** that answers questions using **only** the content from your uploaded PDFs (such as financial filings, contracts, and multi-page reports).

---

## 🌟 Upgraded Features

- **📊 Table-Aware Chunking**: Chunk size `1500` with `300` overlap ensures financial tables, balance sheets, and metrics stay intact.
- **💾 Disk Persistence**: ChromaDB saves vector embeddings to `./chroma_db`, surviving Streamlit app restarts so you don't have to re-upload files.
- **🔍 Grounding Expander**: View the exact raw context chunks retrieved for every answer inside a collapsible UI box.
- **📍 Page-Level Citations**: Source badges display exact page numbers (e.g. `📄 Bajaj_Q1.pdf (Page 14)`).
- **🎛️ Adjustable Retrieval Depth (`top_k`)**: Slider in the sidebar (4–15) lets you adjust context depth for multi-document comparisons (e.g. QoQ or YoY analysis).
- **⚡ Superfast Groq LLM**: Powered by `llama-3.3-70b-versatile` via Groq.
- **🔒 Security**: Built-in `.gitignore` excludes `.env` and `chroma_db/`.

---

## 🏗️ Architecture

```
Upload PDFs → Text Validation (OCR Check) 
    → Table-Aware Split (1500 chars / 300 overlap) 
    → Local Embeddings (HuggingFace all-MiniLM-L6-v2)
    → Persistent Vector Store (ChromaDB on disk) 
    → Retrieve top_k chunks (configurable 4-15)
    → Groq LLM Generation (Strict context-only)
    → Output Answer + Context Expander + Page Citations
```

---

## 🚀 Setup & Launch Instructions

### 1. Install Dependencies

```powershell
pip install -r requirements.txt
```

### 2. Verify `.env` File

Make sure your `.env` contains your Groq API key:
```env
GROQ_API_KEY=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
```

### 3. Run the App

```powershell
streamlit run app.py
```

The application will launch in your browser at `http://localhost:8501`.
