"""
app.py — PDF-based RAG Chatbot (Streamlit)
==========================================
A single-file Streamlit application that lets users:
  • Upload multiple PDFs with persistent storage
  • Ask questions answered ONLY from the uploaded documents
  • Inspect retrieved context chunks in an expander
  • See exact source document and page number citations

Run:  streamlit run app.py
"""

import streamlit as st
from dotenv import load_dotenv
import os
import shutil

from rag_utils import (
    load_pdf,
    split_documents,
    tag_chunks_with_source,
    get_embedding_model,
    load_existing_vectorstore,
    reset_vectorstore,
    create_or_update_vectorstore,
    retrieve_relevant_chunks,
    generate_answer,
    get_llm,
    PERSIST_DIR,
)

# ---------------------------------------------------------------------------
# Environment & Config
# ---------------------------------------------------------------------------
load_dotenv()  # Load .env file if present

# ---------------------------------------------------------------------------
# Page Config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="📄 Financial & Document RAG Chatbot",
    page_icon="📄",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Custom Styling — Premium dark theme with glassmorphism accents
# ---------------------------------------------------------------------------
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0f0f23 0%, #1a1a3e 100%);
    }
    section[data-testid="stSidebar"] .stMarkdown {
        color: #e0e0ff;
    }

    [data-testid="stFileUploader"] {
        border: 2px dashed #4f46e5;
        border-radius: 12px;
        padding: 1rem;
        transition: border-color 0.3s ease;
    }
    [data-testid="stFileUploader"]:hover {
        border-color: #818cf8;
    }

    [data-testid="stChatMessage"] {
        border-radius: 12px;
        margin-bottom: 0.5rem;
    }

    .source-badge {
        display: inline-block;
        background: linear-gradient(135deg, #4f46e5, #7c3aed);
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        margin: 3px 6px 3px 0;
    }

    .doc-card {
        background: linear-gradient(135deg, rgba(79,70,229,0.15), rgba(124,58,237,0.08));
        border-left: 4px solid #4f46e5;
        border-radius: 8px;
        padding: 0.75rem 1rem;
        margin: 0.4rem 0;
    }

    .gradient-text {
        background: linear-gradient(135deg, #818cf8, #c084fc);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 700;
        font-size: 1.6rem;
    }

    .chunk-box {
        background-color: rgba(255, 255, 255, 0.05);
        border-radius: 8px;
        padding: 10px;
        margin-bottom: 10px;
        border-left: 3px solid #818cf8;
        font-size: 0.85rem;
    }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Session State Initialisation
# ---------------------------------------------------------------------------
if "embedding_model" not in st.session_state:
    st.session_state.embedding_model = None

if "vectorstore" not in st.session_state:
    st.session_state.vectorstore = None

if "processed_docs" not in st.session_state:
    st.session_state.processed_docs = set()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# ---- Auto-load existing ChromaDB from disk on startup ----
if st.session_state.vectorstore is None and os.path.exists(PERSIST_DIR):
    if st.session_state.embedding_model is None:
        st.session_state.embedding_model = get_embedding_model()
    existing_store = load_existing_vectorstore(st.session_state.embedding_model)
    if existing_store is not None:
        st.session_state.vectorstore = existing_store


# ---------------------------------------------------------------------------
# Sidebar — PDF Upload & Settings
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown('<p class="gradient-text">📄 PDF RAG Chatbot</p>', unsafe_allow_html=True)
    st.caption("Table-aware chunking • Persistent vector store • Page citations")

    st.divider()

    # ---- API Key Input ----
    api_key = os.getenv("GROQ_API_KEY", "")
    if not api_key:
        api_key = st.text_input(
            "🔑 Groq API Key",
            type="password",
            placeholder="gsk-...",
            help="Set GROQ_API_KEY in a .env file or paste here.",
        )

    st.divider()

    # ---- PDF Upload ----
    st.subheader("📂 Upload Documents")
    uploaded_files = st.file_uploader(
        "Choose PDF files",
        type=["pdf"],
        accept_multiple_files=True,
        help="Upload PDFs. Tables and multi-page reports are preserved automatically.",
    )

    # ---- Retrieval Settings ----
    st.divider()
    selected_model = st.selectbox(
        "🤖 Groq LLM Model",
        options=["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.6-27b"],
        index=0,
        help="Select an active Groq model. 'openai/gpt-oss-120b' is Groq's top recommended model.",
    )

    top_k = st.slider(
        "🎯 Retrieval Depth (top_k chunks)",
        min_value=4,
        max_value=15,
        value=8,
        help="Higher values (8-10+) fetch context from multiple documents (useful for QoQ comparisons).",
    )

    # ---- Process Button ----
    if uploaded_files:
        if st.button("⚙️ Process Uploaded PDFs", use_container_width=True, type="primary"):
            if st.session_state.embedding_model is None:
                with st.spinner("🔄 Loading embedding model..."):
                    st.session_state.embedding_model = get_embedding_model()

            new_count = 0
            for pdf_file in uploaded_files:
                if pdf_file.name in st.session_state.processed_docs:
                    st.info(f"⏭️ '{pdf_file.name}' already loaded in session — skipping.")
                    continue

                try:
                    with st.spinner(f"📖 Processing '{pdf_file.name}'..."):
                        # STEP 1 — Load & validate (OCR check)
                        pages = load_pdf(pdf_file)

                        # STEP 2 — Table-aware split (1500 chunk / 300 overlap)
                        chunks = split_documents(pages, chunk_size=1500, chunk_overlap=300)

                        # STEP 3 — Tag with filename and 1-indexed page number
                        chunks = tag_chunks_with_source(chunks, pdf_file.name)

                        # STEP 4 — Embed & store in persistent ChromaDB
                        st.session_state.vectorstore = create_or_update_vectorstore(
                            chunks=chunks,
                            embedding_model=st.session_state.embedding_model,
                            existing_vectorstore=st.session_state.vectorstore,
                        )

                        st.session_state.processed_docs.add(pdf_file.name)
                        new_count += 1

                except ValueError as ve:
                    st.error(f"⚠️ {ve}")
                except Exception as e:
                    st.error(f"❌ Error processing '{pdf_file.name}': {e}")

            if new_count:
                st.success(f"✅ {new_count} new document(s) added to knowledge base!")

    st.divider()

    # ---- Processed Documents List ----
    st.subheader("📚 Active Knowledge Base")
    if st.session_state.processed_docs:
        for doc_name in sorted(st.session_state.processed_docs):
            st.markdown(
                f'<div class="doc-card">📄 {doc_name}</div>',
                unsafe_allow_html=True,
            )
        st.caption(f"{len(st.session_state.processed_docs)} document(s) in active session")
    elif os.path.exists(PERSIST_DIR) and len(os.listdir(PERSIST_DIR)) > 0:
        st.success("💾 Persisted database loaded from disk.")
    else:
        st.info("No documents loaded yet.")

    st.divider()

    # ---- Reset Button ----
    if st.button("🗑️ Reset & Delete Knowledge Base", use_container_width=True):
        # Properly close ChromaDB connection before deleting (fixes Windows file-lock)
        success = reset_vectorstore(st.session_state.vectorstore)
        st.session_state.vectorstore = None
        st.session_state.embedding_model = None
        st.session_state.processed_docs = set()
        st.session_state.chat_history = []
        if success:
            st.success("✅ Knowledge base deleted successfully!")
        else:
            st.error("⚠️ Could not fully delete database files. Please stop Streamlit and manually delete the 'chroma_db' folder.")
        st.rerun()


# ---------------------------------------------------------------------------
# Main Area — Chat Interface
# ---------------------------------------------------------------------------
st.markdown("## 💬 Financial & Document RAG Assistant")

if st.session_state.vectorstore is None and not os.path.exists(PERSIST_DIR):
    st.warning("👈 Please upload and process at least one PDF from the sidebar before chatting.")

# ---- Render existing chat history ----
for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        
        # Display retrieved context chunks expander if present
        if msg.get("chunks"):
            with st.expander("🔍 View Retrieved Context Chunks"):
                for idx, chunk in enumerate(msg["chunks"], 1):
                    src = chunk.metadata.get("source", "Unknown")
                    pg = chunk.metadata.get("page_number") or (chunk.metadata.get("page", 0) + 1)
                    st.markdown(
                        f"**Chunk {idx}** — *{src} (Page {pg})*\n```text\n{chunk.page_content}\n```"
                    )

        # Show page-level source citations
        if msg["role"] == "assistant" and msg.get("sources"):
            sources_html = " ".join(
                f'<span class="source-badge">📄 {s}</span>' for s in msg["sources"]
            )
            st.markdown(f"**Sources:** {sources_html}", unsafe_allow_html=True)

# ---- Chat input ----
if user_question := st.chat_input("Ask a question about your documents (e.g. 'Compare NPA between Q1 and Q2')..."):

    # Guard: no documents loaded
    if st.session_state.vectorstore is None and not os.path.exists(PERSIST_DIR):
        st.warning("⚠️ Knowledge base is empty. Please upload and process PDFs first.")
        st.stop()

    # Guard: no API key
    if not api_key:
        st.warning("⚠️ Please provide your Groq API key in the sidebar or .env file.")
        st.stop()

    # Display the user message
    with st.chat_message("user"):
        st.markdown(user_question)
    st.session_state.chat_history.append({"role": "user", "content": user_question})

    # ---- RAG Pipeline: Retrieve → Generate → Cite ----
    with st.chat_message("assistant"):
        with st.spinner("🔍 Searching documents & generating answer..."):
            try:
                # Ensure vectorstore is loaded
                if st.session_state.vectorstore is None:
                    if st.session_state.embedding_model is None:
                        st.session_state.embedding_model = get_embedding_model()
                    st.session_state.vectorstore = load_existing_vectorstore(st.session_state.embedding_model)

                # STEP 5 — Retrieve top-k relevant chunks
                relevant_chunks = retrieve_relevant_chunks(
                    vectorstore=st.session_state.vectorstore,
                    query=user_question,
                    top_k=top_k,
                )

                if not relevant_chunks:
                    answer = "I couldn't find any relevant information in the uploaded documents."
                    sources = []
                else:
                    # STEP 6 — Generate answer using Groq LLM
                    llm = get_llm(api_key=api_key, model=selected_model)
                    answer, sources = generate_answer(
                        llm=llm,
                        question=user_question,
                        chunks=relevant_chunks,
                    )

            except Exception as e:
                answer = f"❌ An error occurred: {e}"
                sources = []
                relevant_chunks = []

        # Display answer
        st.markdown(answer)

        # Show retrieved chunks in an expander for grounding
        if relevant_chunks:
            with st.expander("🔍 View Retrieved Context Chunks"):
                for idx, chunk in enumerate(relevant_chunks, 1):
                    src = chunk.metadata.get("source", "Unknown")
                    pg = chunk.metadata.get("page_number") or (chunk.metadata.get("page", 0) + 1)
                    st.markdown(
                        f"**Chunk {idx}** — *{src} (Page {pg})*\n```text\n{chunk.page_content}\n```"
                    )

        # STEP 7 — Display citations with page numbers
        if sources:
            sources_html = " ".join(
                f'<span class="source-badge">📄 {s}</span>' for s in sources
            )
            st.markdown(f"**Sources:** {sources_html}", unsafe_allow_html=True)

    # Persist message & context into session state
    st.session_state.chat_history.append({
        "role": "assistant",
        "content": answer,
        "sources": sources,
        "chunks": relevant_chunks,
    })
